/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 int BLOCKS[7][4]=
 {{1,3,5,7} , {2,4,5,7} , {3,5,4,6} , {3,5,4,7} , {2,3,5,7} , {3,5,7,6} , {2,3,4,5}};
 
